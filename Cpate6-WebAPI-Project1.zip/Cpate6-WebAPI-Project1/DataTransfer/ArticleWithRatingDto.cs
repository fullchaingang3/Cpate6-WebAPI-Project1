﻿namespace Cpate6_WebAPI_Project1.DataTransfer
{
    public class ArticleWithRatingDto
    {
        public string Title { get; set; }
        public double AvgRating { get; set; }
    }
}
