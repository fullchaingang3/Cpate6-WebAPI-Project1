﻿namespace Cpate6_WebAPI_Project1.DataTransfer
{
    public class RatingWithNameDto
    {
        public double Rating { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
