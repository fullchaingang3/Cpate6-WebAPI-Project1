﻿namespace Cpate6_WebAPI_Project1.Models
{
    public class UserLevel
    {
        /// <summary>
        /// This is an entity class for the UserLevel table in the database
        /// </summary>
        public int LevelId { get; set; }
        public string? Level { get; set; }
    }
}
